# Blockchain-Based-Voting-System

# Watch the demo how it works here:
https://www.youtube.com/watch?v=f22rJ1m7JBs&ab_channel=ROOMYAN
