import React, { useContext,useState, useRef } from "react";
import { RouteProps } from "react-router";
import { AuthContext } from "../../contexts/Auth";
import { exportComponentAsPNG } from "react-component-export-image";


const Profile = (props: RouteProps) => {
  const authContext = useContext(AuthContext);
  const name = authContext.name;
  console.log({ authContext });

  const certificateWrapper = useRef(null);
  const [profileName, setProfileName] = useState(name);

  const handleGetCertificate = (e: { preventDefault: () => void; }) => {
    e.preventDefault();
    exportComponentAsPNG(certificateWrapper, {
      html2CanvasOptions: { backgroundColor: null },
    });
  };
  return (
    <div className="profile-wrapper">
      <div className="left-panel">
        <div className="person-icon">
          <i className="bi bi-person-circle"></i>
        </div>
        <div className="text-normal username">{authContext.name}</div>
        <button onClick={authContext.logout} className="button-primary">
          Logout
        </button>
        {authContext.name !== 'John' && (
        <div>
        <button onClick={handleGetCertificate} style={{ backgroundColor: "#368682", color: "white", margin: "4px" }}>
          Get Certificate
        </button>
        </div>
        )}
        {authContext.name !== 'John' && (
        <div id="downloadWrapper" ref={certificateWrapper}>
        <div style={{ boxShadow: "0 0 5px #000", borderRadius: "10px", overflow: "hidden", position: "relative" }}>
        <p style={{ fontFamily: "Sans Serif", margin: "0", position: "absolute", left: "280px", top: "138px", fontSize: "25pt" }}>{profileName}</p>
            <img style={{display: "block"}} src="https://i.imgur.com/6FIxK3u.png" alt="Certificate" />
          </div>
        </div>
        )}
        
   
    

      </div>

      <div className="right-panel">
        <span className="title-small">Profile</span>

        <div className="skeleton"></div>
        <div className="skeleton"></div>
        <div className="skeleton"></div>
        <div className="skeleton"></div>
      </div>
    </div>
  );
};

export default Profile;
