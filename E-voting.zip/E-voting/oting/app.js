//jshint esversion:6
const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const mongoose = require("mongoose");
var fs = require("fs");
const faceapi = require("face-api.js");
//const canvas = require('canvas');

const app = express();

app.use(express.static("public"));
app.set("view engine", "ejs");

app.use(
  bodyParser.urlencoded({
    limit: "50mb",
    extended: true,
  })
);
app.use(express.json({ limit: "50mb" }));

mongoose.set("strictQuery", true);
mongoose
  .connect(
    "mongodb+srv://manu:manu@cluster0.gaf4wel.mongodb.net/?retryWrites=true&w=majority",
    { useNewUrlParser: true, useUnifiedTopology: true }
  )
  .then(() => {
    console.log(`CONNECTED TO MONGO!`);
  })
  .catch((err) => {
    console.log(`OH NO! MONGO CONNECTION ERROR!`);
    console.log(err);
  });

const userSchema = {
  VoterID: String,
  password: String,
};

const User = new mongoose.model("User", userSchema);

app.get("/", function (req, res) {
  res.render("home");
});

app.get("/login", function (req, res) {
  res.render("login");
});

app.get("/register", function (req, res) {
  res.render("register");
});

app.post("/register", function (req, res) {
  const newUser = new User({
    VoterID: req.body.VoterID,
    password: req.body.password,
  });
  try {
    let base64String = req.body.image64;

    let base64Image = base64String.split(";base64,").pop();
    const k = "imag/" + newUser.VoterID + ".jpg";
    fs.writeFile(k, base64Image, { encoding: "base64" }, function (err) {
      console.log("File created");
    });
  } catch (error) {}

  newUser.save();
  res.status(200).send("User created successfully");
});

app.get("/secrets", (req, res) => {
  res.render("secrets");
});

app.post("/login", function (req, res) {
  const VoterID = req.body.VoterID;
  const password = req.body.password;

  const os = require("os");

  function getWifiIpAddress() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
      for (const iface of interfaces[name]) {
        if (
          iface.family === "IPv4" &&
          iface.internal === false &&
          name === "Wi-Fi"
        ) {
          return iface.address;
        }
      }
    }
    return null;
  }

  const allowedIpRanges = [
    ["192.168.0.0", "192.168.255.255"], // Example IP address range 1
    ["10.0.0.0", "10.255.255.255"], // Example IP address range 2
  ];

  // Helper function to check if an IP address falls within the allowed ranges
  function isIpInRange(ip) {
    for (const [start, end] of allowedIpRanges) {
      if (ip >= start && ip <= end) {
        return true;
      }
    }
    return false;
  }

  const wifiIpAddress = getWifiIpAddress();
  var ipcheck = isIpInRange(wifiIpAddress);

  let base64Strin = req.body.image64;

  try {
    let base64Imag = base64Strin.split(";base64,").pop();
    const k = "samp/" + VoterID + ".jpg";
    fs.writeFile(k, base64Imag, { encoding: "base64" }, function (err) {
      console.log("File created");
    });
  } catch (error) {}

  var result = "g";

  const { spawn } = require("child_process");

  const python = spawn("python", ["arraysum.py"]);

  const imgLocation = "" + VoterID;

  python.stdin.write(imgLocation + "\n");
  python.stdin.end();

  python.stdout.on("data", function (data) {
    result = data.toString();
    console.log(result);

    User.findOne({ VoterID: VoterID })
      .then((foundUser) => {
        if (result === "[True]") {
          res.redirect("http://localhost:3000/login");
        } else {
        }
      })
      .catch((error) => {
        //When there are errors We handle them here

        console.log(error);
        res.send(400, "Bad Request");
      });
  });

  python.stderr.on("data", function (data) {
    console.error(data.toString());
  });

  console.log(result);
});

app.listen(3001, function () {
  console.log("Server started on port 3001.");
});
